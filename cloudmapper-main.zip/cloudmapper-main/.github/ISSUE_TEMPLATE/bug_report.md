---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

Please mention the following:
- What command was run?
- Are you working out of a virtualenv environment, Docker, or something else?
